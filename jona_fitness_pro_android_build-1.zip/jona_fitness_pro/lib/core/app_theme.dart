import 'package:flutter/material.dart';

class AppTheme {
  static const lime = Color(0xFFA3E635);
  static const background = Color(0xFF090D0B);
  static const surface = Color(0xFF151C18);

  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: const ColorScheme.dark(
          primary: lime,
          secondary: Color(0xFFB9F36B),
          surface: surface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: background,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: surface,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFF29352D)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0D130F),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF354238)),
          ),
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: surface,
          indicatorColor: Color(0xFF293B20),
          labelTextStyle: WidgetStatePropertyAll(
            TextStyle(fontSize: 11, color: Colors.white70),
          ),
        ),
        useMaterial3: true,
      );
}
