import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});
  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  final _weight = TextEditingController();
  final _waist = TextEditingController();
  String _status = 'Todavía no hay registros guardados.';

  @override
  void dispose() {
    _weight.dispose();
    _waist.dispose();
    super.dispose();
  }

  void _save() {
    if (_weight.text.trim().isEmpty && _waist.text.trim().isEmpty) {
      setState(() => _status = 'Ingresá al menos un dato.');
      return;
    }
    setState(() => _status =
      'Registro local de prueba: peso ${_weight.text.isEmpty ? '—' : '${_weight.text} kg'} · cintura ${_waist.text.isEmpty ? '—' : '${_waist.text} cm'}.');
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('MI PROGRESO', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      Text('Registrá tus avances físicos.', style: TextStyle(color: Colors.grey.shade400)),
      const SizedBox(height: 18),
      Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: _weight, keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Peso actual (kg)')),
          const SizedBox(height: 12),
          TextField(controller: _waist, keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Cintura (cm)')),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: _save, child: const Text('Guardar registro'))),
          const SizedBox(height: 10),
          Text(_status, style: const TextStyle(color: AppTheme.lime)),
        ]),
      )),
      const SizedBox(height: 12),
      const Card(child: ListTile(
        leading: Icon(Icons.show_chart, color: AppTheme.lime),
        title: Text('Historial y gráficos'),
        subtitle: Text('Se habilitarán al conectar la base de datos.'),
      )),
    ],
  );
}
