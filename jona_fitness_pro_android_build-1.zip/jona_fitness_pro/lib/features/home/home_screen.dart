import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('PERSONAL TRAINER', style: TextStyle(
          color: AppTheme.lime, letterSpacing: 3, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        const Text('JONA FITNESS PRO', style: TextStyle(
          fontSize: 27, fontWeight: FontWeight.w900)),
        const SizedBox(height: 22),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('TU MEJOR VERSIÓN EMPIEZA HOY',
                style: TextStyle(color: AppTheme.lime, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text('ENTRENÁ MÁS.\nEVOLUCIONÁ MÁS.',
                style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('Rutinas, objetivos y seguimiento en un solo lugar.',
                style: TextStyle(color: Colors.grey.shade400)),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        const Text('TU PANEL', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Row(children: [
          Expanded(child: _Metric(label: 'Sesiones', value: '—')),
          SizedBox(width: 10),
          Expanded(child: _Metric(label: 'Objetivo', value: 'Activo')),
        ]),
        const SizedBox(height: 20),
        const Text('ESPECIALIDADES', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          _Tag(icon: Icons.fitness_center, label: 'Musculación'),
          _Tag(icon: Icons.directions_run, label: 'Running'),
          _Tag(icon: Icons.bolt, label: 'Funcional'),
          _Tag(icon: Icons.terrain, label: 'OCR / HYROX'),
        ]),
        const SizedBox(height: 22),
        Text('Los datos que ves en esta versión son de demostración.',
          style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
      ],
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: TextStyle(color: Colors.grey.shade400)),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold,
        color: AppTheme.lime)),
    ]),
  ));
}

class _Tag extends StatelessWidget {
  const _Tag({required this.icon, required this.label});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Chip(
    avatar: Icon(icon, size: 17, color: AppTheme.lime),
    label: Text(label),
    backgroundColor: AppTheme.surface,
    side: const BorderSide(color: Color(0xFF29352D)),
  );
}
