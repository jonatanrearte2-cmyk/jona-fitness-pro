import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('MI PERFIL', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 18),
      const Card(child: Padding(
        padding: EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(radius: 34, backgroundColor: Color(0xFF293B20),
            child: Text('JT', style: TextStyle(color: AppTheme.lime, fontSize: 23, fontWeight: FontWeight.w900))),
          SizedBox(height: 14),
          Text('JONA FITNESS PRO', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          Text('Cuenta de demostración', style: TextStyle(color: Colors.white60)),
          Divider(height: 26),
          Text('Entrenador: Jona Rearte'),
          SizedBox(height: 8),
          Text('Musculación · Funcional · OCR · Running'),
          SizedBox(height: 8),
          Text('Plan: Demo'),
        ]),
      )),
      const SizedBox(height: 12),
      const Card(child: ListTile(
        leading: Icon(Icons.lock_outline, color: AppTheme.lime),
        title: Text('Privacidad y seguridad'),
        subtitle: Text('Autenticación y permisos pendientes de integración.'),
      )),
    ],
  );
}
