import 'package:flutter/material.dart';
import '../../core/app_theme.dart';

class RoutinesScreen extends StatelessWidget {
  const RoutinesScreen({super.key});

  static const exercises = [
    ('Sentadilla', '4 × 8'),
    ('Peso muerto rumano', '3 × 10'),
    ('Hip thrust', '3 × 12'),
    ('Gemelos', '3 × 15'),
  ];

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('MIS RUTINAS', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      Text('Planes asignados por tu entrenador.', style: TextStyle(color: Colors.grey.shade400)),
      const SizedBox(height: 18),
      Card(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('DÍA 1 · FUERZA', style: TextStyle(color: AppTheme.lime, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Tren inferior', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...exercises.map((item) => ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(item.$1),
            trailing: Text(item.$2, style: const TextStyle(color: AppTheme.lime, fontWeight: FontWeight.bold)),
          )),
        ]),
      )),
      const SizedBox(height: 12),
      const Card(child: ListTile(
        leading: Icon(Icons.directions_run, color: AppTheme.lime),
        title: Text('Running + core'),
        subtitle: Text('Plan de ejemplo pendiente de personalización'),
      )),
      const SizedBox(height: 12),
      Text('Aviso: estos ejercicios son ilustrativos. Las rutinas reales deberán ser asignadas por un profesional según el alumno.',
        style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
    ],
  );
}
