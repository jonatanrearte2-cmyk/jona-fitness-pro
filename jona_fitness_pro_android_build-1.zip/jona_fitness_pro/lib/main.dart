import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'core/app_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Próximo paso: inicializar Supabase con variables seguras de entorno.
  // No guardar claves secretas de servidor dentro de la aplicación móvil.

  runApp(const JonaFitnessApp());
}

class JonaFitnessApp extends StatelessWidget {
  const JonaFitnessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JONA FITNESS PRO',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const AppShell(),
    );
  }
}
