-- Esquema inicial multiempresa para JONA FITNESS PRO.
-- Revisar y probar en un proyecto Supabase de desarrollo antes de producción.

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null check (role in ('platform_admin','gym_owner','trainer','student')),
  organization_id uuid references public.organizations(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.routines (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  trainer_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null default '',
  created_at timestamptz not null default now()
);

create table public.progress_entries (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  weight_kg numeric(6,2),
  waist_cm numeric(6,2),
  recorded_at timestamptz not null default now()
);

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.routines enable row level security;
alter table public.progress_entries enable row level security;

-- Políticas mínimas iniciales: el usuario puede leer su propio perfil.
create policy "profile_read_own"
on public.profiles for select
to authenticated
using (id = auth.uid());

-- Las políticas de organización, entrenadores, alumnos y administradores
-- deben completarse antes de habilitar datos reales. No activar acceso público.
-- Nunca colocar service_role key en una app móvil.
