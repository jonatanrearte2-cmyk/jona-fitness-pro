# JONA FITNESS PRO — starter de desarrollo

Proyecto inicial Flutter para Android/iOS. Incluye navegación, tema oscuro negro/verde,
pantallas de inicio, rutinas, progreso y perfil, más un esquema SQL inicial para Supabase.

## Requisitos
- Flutter SDK estable
- Android Studio y/o Xcode (para compilar iOS se necesita macOS con Xcode)
- Cuenta de Supabase para backend cuando llegue esa etapa

## Ejecutar
```bash
flutter doctor
flutter pub get
flutter run
```

## Estructura
- `lib/core`: tema y navegación principal.
- `lib/features`: pantallas por módulo.
- `supabase/schema.sql`: esquema inicial multiempresa.

## Estado actual
Es un prototipo de interfaz. No tiene autenticación real, sincronización en la nube,
pagos, permisos completos, panel web ni publicación en tiendas. Los datos son de prueba.

## Próximas etapas técnicas
1. Crear proyecto Supabase de desarrollo.
2. Implementar registro/login y recuperación de contraseña.
3. Completar políticas RLS por organización y rol, y probar aislamiento entre gimnasios.
4. Crear gestión de alumnos, entrenadores, rutinas y ejercicios.
5. Agregar almacenamiento seguro de fotos de progreso con consentimiento.
6. Integrar Mercado Pago mediante backend seguro y webhooks verificados.
7. Añadir pruebas automatizadas, monitoreo, privacidad, términos y revisión de seguridad.
8. Preparar builds Android/iOS y publicación en tiendas.

## Seguridad
No introducir claves privadas, credenciales de Mercado Pago ni `service_role` de Supabase
en el código Flutter. Usar variables de entorno y backend para operaciones privilegiadas.
Los datos de salud/medidas y fotografías requieren controles de acceso y consentimiento.


## Compilar APK desde GitHub Actions (sin instalar Flutter en el celular)
1. Subir el contenido del proyecto a un repositorio GitHub.
2. Abrir la pestaña **Actions** del repositorio.
3. Elegir **Build Android APK** y pulsar **Run workflow**.
4. Al finalizar, abrir la ejecución y descargar el artefacto `jona-fitness-pro-android-apk`.
5. Extraer el ZIP descargado y abrir el APK en Android para instalarlo.

El workflow genera el APK en la nube. Es una compilación inicial de demostración;
no habilita todavía autenticación, backend ni pagos reales.
